# Object Verify

`objverify` is a Python utility that allows for complex typechecking in complex or nested Python objects using dictionaries. This module is still under development. Examples can be found in `test.py`.

